package springmvc.model.dao;

import springmvc.model.Acadamicrecord;

public interface AcadamicrecordDao 

{

	Acadamicrecord saveAcadamicrecord(Acadamicrecord aca);
	
	Acadamicrecord getAcadamicrecord(Integer aca);
	
	
	
	
	
}
